
import React from 'react';
import Typography from './Typography';

export default {

  path: '/typography',

  action() {
    return <Typography />;
  },

};
