
import React from 'react';
import Icons from './Icons';

export default {

  path: '/icons',

  action() {
    return <Icons />;
  },

};
