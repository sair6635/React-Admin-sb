
import React from 'react';
import Grid from './Grid';

export default {

  path: '/grid',

  action() {
    return <Grid />;
  },

};
